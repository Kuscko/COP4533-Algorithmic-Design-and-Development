import math 

def gcd_math(a, b):
    """
    Calculates the Greatest Common Denominator (GCD) using the math library.
    """
    return math.gcd(a, b)